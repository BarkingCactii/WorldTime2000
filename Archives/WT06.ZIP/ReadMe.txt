WorldTime2000 Note

This version uses HTML help. This feature normally would require MS Internet
Explorer 4.01 or later be installed on your computer, because of the Windows
OS enhancements it adds for HTML viewing. This program has been statically
built which means it requires no external products be installed.
If you are using Netscape, and do NOT have Explorer 4.01 or later
installed, and find HTML does not work, please let me know.
